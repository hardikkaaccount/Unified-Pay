import React from 'react';
import { Wallet } from 'lucide-react';

interface WalletConnectProps {
  isConnected: boolean;
  address: string;
  onConnect: () => void;
}

export const WalletConnect: React.FC<WalletConnectProps> = ({
  isConnected,
  address,
  onConnect,
}) => {
  return (
    <div className="absolute top-4 right-4">
      {isConnected ? (
        <div className="flex items-center gap-2 bg-green-100 px-4 py-2 rounded-lg">
          <Wallet size={20} className="text-green-600" />
          <span className="text-green-600">
            {address.slice(0, 6)}...{address.slice(-4)}
          </span>
        </div>
      ) : (
        <button
          onClick={onConnect}
          className="flex items-center gap-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
        >
          <Wallet size={20} />
          Connect Wallet
        </button>
      )}
    </div>
  );
};