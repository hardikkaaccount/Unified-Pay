import React from 'react';
import { Trash2 } from 'lucide-react';
import { validateAddress, validateAmount } from '../utils/validation';

interface AddressInputProps {
  index: number;
  address: string;
  amount: string;
  onAddressChange: (index: number, value: string) => void;
  onAmountChange: (index: number, value: string) => void;
  onRemove: (index: number) => void;
}

export const AddressInput: React.FC<AddressInputProps> = ({
  index,
  address,
  amount,
  onAddressChange,
  onAmountChange,
  onRemove,
}) => {
  const addressValidation = validateAddress(address);
  const amountValidation = validateAmount(amount);

  return (
    <div className="flex flex-col gap-2 mb-4">
      <div className="flex gap-4 items-start">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Recipient Address (0x...)"
            value={address}
            onChange={(e) => onAddressChange(index, e.target.value.trim())}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
              address && !addressValidation.isValid ? 'border-red-500' : 'border-gray-300'
            }`}
          />
          {address && !addressValidation.isValid && (
            <p className="text-red-500 text-sm mt-1">{addressValidation.error}</p>
          )}
        </div>
        <div className="w-48">
          <input
            type="text"
            placeholder="Amount in ETH"
            value={amount}
            onChange={(e) => onAmountChange(index, e.target.value)}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
              amount && !amountValidation.isValid ? 'border-red-500' : 'border-gray-300'
            }`}
          />
          {amount && !amountValidation.isValid && (
            <p className="text-red-500 text-sm mt-1">{amountValidation.error}</p>
          )}
        </div>
        <button
          onClick={() => onRemove(index)}
          className="p-2 text-red-500 hover:text-red-700 transition-colors"
          type="button"
        >
          <Trash2 size={20} />
        </button>
      </div>
    </div>
  );
};