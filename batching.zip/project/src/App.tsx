import React, { useState } from 'react';
import { ethers } from 'ethers';
import { Plus } from 'lucide-react';
import toast, { Toaster } from 'react-hot-toast';
import { AddressInput } from './components/AddressInput';
import { WalletConnect } from './components/WalletConnect';
import { useWallet } from './hooks/useWallet';
import { validateAddress, validateAmount } from './utils/validation';
import { getProvider, getContract } from './utils/ethereum';

interface Recipient {
  address: string;
  amount: string;
}

function App() {
  const { isConnected, address, connect } = useWallet();
  const [recipients, setRecipients] = useState<Recipient[]>([{ address: '', amount: '' }]);
  const [isLoading, setIsLoading] = useState(false);

  const addRecipient = () => {
    setRecipients([...recipients, { address: '', amount: '' }]);
  };

  const removeRecipient = (index: number) => {
    if (recipients.length > 1) {
      setRecipients(recipients.filter((_, i) => i !== index));
    }
  };

  const handleAddressChange = (index: number, value: string) => {
    const newRecipients = [...recipients];
    newRecipients[index].address = value;
    setRecipients(newRecipients);
  };

  const handleAmountChange = (index: number, value: string) => {
    const newRecipients = [...recipients];
    newRecipients[index].amount = value;
    setRecipients(newRecipients);
  };

  const validateForm = () => {
    for (const recipient of recipients) {
      const addressValidation = validateAddress(recipient.address);
      const amountValidation = validateAmount(recipient.amount);
      
      if (!addressValidation.isValid) {
        toast.error(addressValidation.error || 'Invalid address');
        return false;
      }
      if (!amountValidation.isValid) {
        toast.error(amountValidation.error || 'Invalid amount');
        return false;
      }
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isConnected) {
      toast.error('Please connect your wallet first');
      return;
    }

    if (!validateForm()) {
      return;
    }

    try {
      setIsLoading(true);
      const provider = getProvider();
      const contract = await getContract(provider);

      const addresses = recipients.map(r => r.address.trim());
      const amounts = recipients.map(r => ethers.parseEther(r.amount));
      const totalAmount = amounts.reduce((a, b) => a + b, 0n);

      const tx = await contract.batchTransfer(addresses, amounts, {
        value: totalAmount
      });

      toast.promise(tx.wait(), {
        loading: 'Processing transaction...',
        success: 'Batch transfer successful!',
        error: 'Transaction failed'
      });

      await tx.wait();
      setRecipients([{ address: '', amount: '' }]);
    } catch (error: any) {
      console.error(error);
      toast.error(error.message || 'Transaction failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-right" />
      <WalletConnect
        isConnected={isConnected}
        address={address}
        onConnect={connect}
      />
      
      <div className="max-w-4xl mx-auto pt-20 px-4">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-8">
            Batch ETH Transfer
          </h1>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              {recipients.map((recipient, index) => (
                <AddressInput
                  key={index}
                  index={index}
                  address={recipient.address}
                  amount={recipient.amount}
                  onAddressChange={handleAddressChange}
                  onAmountChange={handleAmountChange}
                  onRemove={removeRecipient}
                />
              ))}
            </div>

            <div className="flex gap-4">
              <button
                type="button"
                onClick={addRecipient}
                className="flex items-center gap-2 px-4 py-2 text-blue-500 border border-blue-500 rounded-lg hover:bg-blue-50 transition-colors"
              >
                <Plus size={20} />
                Add Recipient
              </button>

              <button
                type="submit"
                disabled={isLoading || !isConnected}
                className={`px-6 py-2 bg-blue-500 text-white rounded-lg ${
                  (isLoading || !isConnected)
                    ? 'opacity-50 cursor-not-allowed'
                    : 'hover:bg-blue-600'
                } transition-colors`}
              >
                {isLoading ? 'Processing...' : 'Send Batch Transfer'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default App;