import { ethers } from 'ethers';

export interface ValidationResult {
  isValid: boolean;
  error?: string;
}

export const validateAddress = (address: string): ValidationResult => {
  try {
    if (!address) {
      return { isValid: false, error: 'Address is required' };
    }
    // Remove any whitespace
    const cleanAddress = address.trim();
    if (!ethers.isAddress(cleanAddress)) {
      return { isValid: false, error: 'Invalid Ethereum address' };
    }
    return { isValid: true };
  } catch (error) {
    return { isValid: false, error: 'Invalid address format' };
  }
};

export const validateAmount = (amount: string): ValidationResult => {
  try {
    if (!amount) {
      return { isValid: false, error: 'Amount is required' };
    }
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return { isValid: false, error: 'Amount must be greater than 0' };
    }
    // Try to parse as ether to validate format
    ethers.parseEther(amount);
    return { isValid: true };
  } catch (error) {
    return { isValid: false, error: 'Invalid amount format' };
  }
};