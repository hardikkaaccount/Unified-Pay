import { ethers } from 'ethers';
import { TRANSACTION_BATCHING_ABI } from '../contracts/TransactionBatching';

export const CONTRACT_ADDRESS = '0xA8fDb7aE2CC96c29B1A43920D21F035A54191238';

export const getProvider = () => {
  if (typeof window.ethereum === 'undefined') {
    throw new Error('MetaMask is not installed');
  }
  return new ethers.BrowserProvider(window.ethereum);
};

export const getContract = async (provider: ethers.BrowserProvider) => {
  const signer = await provider.getSigner();
  return new ethers.Contract(CONTRACT_ADDRESS, TRANSACTION_BATCHING_ABI, signer);
};