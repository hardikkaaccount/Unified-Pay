import { useState, useCallback } from 'react';
import { getProvider } from '../utils/ethereum';
import toast from 'react-hot-toast';

export const useWallet = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [address, setAddress] = useState('');

  const connect = useCallback(async () => {
    try {
      const provider = getProvider();
      const accounts = await provider.send('eth_requestAccounts', []);
      setAddress(accounts[0]);
      setIsConnected(true);
      toast.success('Wallet connected successfully!');
    } catch (error) {
      toast.error('Failed to connect wallet');
      console.error(error);
    }
  }, []);

  return {
    isConnected,
    address,
    connect
  };
};