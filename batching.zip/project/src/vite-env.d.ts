/// <reference types="vite/client" />

interface Window {
  ethereum?: any;
}