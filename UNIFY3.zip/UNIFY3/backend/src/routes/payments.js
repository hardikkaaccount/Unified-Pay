import express from 'express';
import { paymentsWrite, paymentsRead } from '../controllers/paymentsController.js';

const router = express.Router();

// Route for writing a payment transaction
router.post('/write', paymentsWrite); // Ensure '/write' is correctly defined

// Route for reading payment transactions
router.post('/read', paymentsRead);

export default router;
