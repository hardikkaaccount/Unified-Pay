import payments from "../models/payment.js";

// In 'paymentsController.js'
export const paymentsWrite = async (req, res) => {
    try {
        const { date, to, keyword, amt, coin, sender } = req.body;
        const payment = new payments({
            date,
            toUPI: to,
            keyword,
            amount: amt,
            sender,
            coin,
        });

        const result = await payment.save(); // Save payment to DB
        console.log("Payment saved:", result);
        return res.json(result); // Return the saved result
    } catch (error) {
        console.error("Error processing payment:", error);
        return res.status(500).json({ message: `Failed due to ${error.message}` });
    }
};


export const paymentsRead = async (req, res) => {
    try {
        const sender = req.body.sender;

        const result = await payments.find({
            'sender': sender,
        });
        console.log(result);
        return res.json(result);
    } catch (error) {
        throw new Error(error);
    }
}
