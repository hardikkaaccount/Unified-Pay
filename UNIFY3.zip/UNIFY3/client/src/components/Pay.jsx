import React, { useState, useEffect } from 'react';
import axios from 'axios';
import api from '../utils/api';
import { Wallet, ArrowRight, DollarSign, FileText, Send, ReceiptText } from 'lucide-react';

function Pay() {
  const [mode, setMode] = useState('pay'); // 'pay' or 'request'
  const [paymentData, setPaymentData] = useState({
    date: new Date().toISOString().slice(0, 16),
    to: '',
    keyword: '',
    amt: '',
    sender: '',
    coin: 'DAI'
  });

  // Initialize the daiBalance state from localStorage, if available
  const [daiBalance, setDaiBalance] = useState(() => {
    const savedBalance = localStorage.getItem('daiBalance');
    return savedBalance ? parseFloat(savedBalance) : 1000.00; // Default to 1000 if not found
  });

  const [loading, setLoading] = useState(false);
  const [metamaskId, setMetamaskId] = useState('');

  useEffect(() => {
    // Fetch user's metamask ID on component mount
    const fetchUserData = async () => {
      try {
        const response = await api.post('/api/auth/fetchdetail', {
          email: localStorage.getItem('userEmail') // Assuming email is stored in localStorage
        });
        if (response.data?.user?.metamaskId) {
          setMetamaskId(response.data.user.metamaskId);
          setPaymentData(prev => ({ ...prev, sender: response.data.user.metamaskId }));
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    fetchUserData();
  }, []);

  const handlePayment = (e) => {
    e.preventDefault();
    setLoading(true);

    // Check if the entered amount is valid and less than or equal to the current balance
    const enteredAmount = parseFloat(paymentData.amt);
    if (isNaN(enteredAmount) || enteredAmount <= 0) {
      alert('Invalid amount.');
      setLoading(false);
      return;
    }

    if (enteredAmount > daiBalance) {
      alert('Insufficient balance.');
      setLoading(false);
      return;
    }

    try {
      // Subtract the amount from the current balance
      const updatedBalance = daiBalance - enteredAmount;

      // Update the balance in the state and localStorage
      setDaiBalance(updatedBalance);
      localStorage.setItem('daiBalance', updatedBalance.toFixed(2));

      // Reset payment data
      setPaymentData(prev => ({
        ...prev,
        to: '',
        keyword: '',
        amt: ''
      }));

      alert('Payment successful');
    } catch (error) {
      console.error('Payment failed:', error);
      alert('Payment failed');
    } finally {
      setLoading(false);
    }
  };

  const handleRequest = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await api.post('/money-transfer/money-requested', {
        receiver: paymentData.to,
        amount: paymentData.amt
      });

      alert('Request sent successfully');
      setPaymentData(prev => ({
        ...prev,
        to: '',
        keyword: '',
        amt: ''
      }));
    } catch (error) {
      console.error('Request failed:', error);
      alert(error.message || 'Request failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e) => {
    if (mode === 'pay') {
      handlePayment(e);
    } else {
      handleRequest(e);
    }
  };

  const handleChange = (e) => {
    setPaymentData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 p-6 w-full">
      <div className="max-w-md mx-auto bg-gray-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-white">
              {mode === 'pay' ? 'Send DAI' : 'Request DAI'}
            </h2>
            <div className="flex items-center bg-gray-700 rounded-lg px-4 py-2">
              <Wallet className="w-5 h-5 text-yellow-400 mr-2" />
              <span className="text-white font-medium">{daiBalance} DAI</span>
            </div>
          </div>

          <div className="flex gap-2 mb-6">
            <button
              onClick={() => setMode('pay')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all duration-200 ${
                mode === 'pay'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-700 text-gray-300'
              }`}
            >
              <Send className="w-4 h-4 inline mr-2" />
              Pay
            </button>
            <button
              onClick={() => setMode('request')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all duration-200 ${
                mode === 'request'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-700 text-gray-300'
              }`}
            >
              <ReceiptText className="w-4 h-4 inline mr-2" />
              Request
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Recipient UPI ID</label>
              <div className="relative">
                <input
                  type="text"
                  name="to"
                  value={paymentData.to}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                  placeholder="Enter UPI ID"
                  required
                />
                <ArrowRight className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Amount (DAI)</label>
              <div className="relative">
                <input
                  type="number"
                  name="amt"
                  value={paymentData.amt}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                  placeholder="0.00"
                  step="0.01"
                  required
                />
                <DollarSign className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Note</label>
              <div className="relative">
                <input
                  type="text"
                  name="keyword"
                  value={paymentData.keyword}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                  placeholder="Add a note"
                  required
                />
                <FileText className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className={`w-full py-3 px-4 rounded-lg text-white font-medium transition-all duration-200 ${
                loading
                  ? 'bg-gray-600 cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700'
              }`}
            >
              {loading ? 'Processing...' : mode === 'pay' ? 'Send DAI' : 'Request DAI'}
            </button>
          </form>
        </div>

        <div className="px-6 py-4 bg-gray-900">
          <p className="text-sm text-gray-400 text-center">
            {mode === 'pay' 
              ? 'Transaction fees (0.2%) may apply. Make sure you have sufficient DAI balance.'
              : 'You will receive DAI once the payment is processed.'}
          </p>
        </div>
      </div>
    </div>
  );
}

export default Pay;
