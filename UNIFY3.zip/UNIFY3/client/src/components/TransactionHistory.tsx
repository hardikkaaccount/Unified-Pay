import React from 'react';
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react';

interface Transaction {
  _id: string;
  date: string;
  toUPI: string;
  sender: string;
  amount: number;
  keyword: string;
}

interface TransactionHistoryProps {
  transactions: Transaction[];
  userUPI: string;
}

const TransactionHistory: React.FC<TransactionHistoryProps> = ({ transactions, userUPI }) => {
  return (
    <div className="w-full max-w-md">
      <h2 className="text-xl font-semibold mb-4">Transaction History</h2>
      <div className="space-y-3">
        {transactions.map((transaction) => {
          const isSent = transaction.sender === userUPI;
          
          return (
            <div
              key={transaction._id}
              className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 flex items-center justify-between"
            >
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-full ${isSent ? 'bg-red-100' : 'bg-green-100'}`}>
                  {isSent ? (
                    <ArrowUpRight className="h-5 w-5 text-red-600" />
                  ) : (
                    <ArrowDownLeft className="h-5 w-5 text-green-600" />
                  )}
                </div>
                <div>
                  <p className="font-medium">
                    {isSent ? transaction.toUPI : transaction.sender}
                  </p>
                  <p className="text-sm text-gray-500">{transaction.keyword}</p>
                  <p className="text-xs text-gray-400">
                    {new Date(transaction.date).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <p className={`font-semibold ${isSent ? 'text-red-600' : 'text-green-600'}`}>
                {isSent ? '-' : '+'}₹{transaction.amount}
              </p>
            </div>
          );
        })}
        {transactions.length === 0 && (
          <p className="text-center text-gray-500">No transactions yet</p>
        )}
      </div>
    </div>
  );
};

export default TransactionHistory;