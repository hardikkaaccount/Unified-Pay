import React, { useState } from 'react';
import { Send, IndianRupee } from 'lucide-react';
import axios from 'axios';
import toast from 'react-hot-toast';

interface PaymentFormProps {
  senderUPI: string;
  onSuccess: () => void;
}

const PaymentForm: React.FC<PaymentFormProps> = ({ senderUPI, onSuccess }) => {
  const [formData, setFormData] = useState({
    to: '',
    amount: '',
    keyword: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await axios.post('http://localhost:5550/api/payments/create', {
        date: new Date(),
        to: formData.to,
        keyword: formData.keyword,
        amt: Number(formData.amount),
        sender: senderUPI,
        coin: 'INR'
      });

      toast.success('Payment successful!');
      setFormData({ to: '', amount: '', keyword: '' });
      onSuccess();
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Payment failed');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 w-full max-w-md">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Recipient's UPI ID
        </label>
        <input
          type="text"
          value={formData.to}
          onChange={(e) => setFormData({ ...formData, to: e.target.value })}
          placeholder="name@upi"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Amount (₹)
        </label>
        <div className="relative">
          <IndianRupee className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-5 w-5" />
          <input
            type="number"
            value={formData.amount}
            onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
            placeholder="0.00"
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
            min="1"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Note
        </label>
        <input
          type="text"
          value={formData.keyword}
          onChange={(e) => setFormData({ ...formData, keyword: e.target.value })}
          placeholder="What's this for?"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          required
        />
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
      >
        <Send className="h-5 w-5" />
        <span>Send Money</span>
      </button>
    </form>
  );
};

export default PaymentForm;