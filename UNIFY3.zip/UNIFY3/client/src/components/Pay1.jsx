import React, { useState, useEffect } from "react";  // Import React and hooks to manage state and side effects
import "../index.css";  // Import custom CSS for styling
import { GrRadial } from "react-icons/gr";  // Import radial icon for UI
import { GrRadialSelected } from "react-icons/gr";  // Import selected radial icon for UI
import axios from 'axios';  // Import Axios for making HTTP requests
import { ConnectWallet, useAddress, useContract, useTransferToken } from '@thirdweb-dev/react';  // Import hooks for wallet connection and token transfer
import Moralis from 'moralis';  // Import Moralis for handling blockchain interactions

const UPI = () => {
  // State variables to store data
  const [upi, setUpi] = useState("");  // State to store UPI ID
  const [amount, setAmount] = useState(0);  // State to store payment amount
  const address = useAddress();  // Hook to get the connected wallet address
  const [DAI, setDAI] = useState('');  // State to store the price of DAI token
  const [keyword, setKeyword] = useState("");  // State to store a keyword for payment (optional)
  const [metamaskID, setMetamaskId] = useState();  // State to store the linked metamask ID
  const walletAddress = useAddress();  // Hook to fetch the wallet address

  // Contract setup for interacting with DAI token
  const { contract: daiToken } = useContract('0xFF34B3d4Aee8ddCd6F9AFFFB6Fe49bD371b8a357');
  const {
    mutateAsync: transferDAI,  // Function to transfer DAI tokens
    isLoading: loadingTransferDAI,  // Loading state for transfer
    error: daiError,  // Error state for transfer
  } = useTransferToken(daiToken);

  useEffect(() => {
    const init1 = async () => {
      try {
        // Start Moralis to interact with blockchain
        await Moralis.start({
          apiKey: "your-api-key-here",  // Replace with actual API key
        });

        // Fetch DAI token price in USD from Moralis API
        const resp = await Moralis.EvmApi.token.getTokenPrice({
          "chain": "0x1",  // Ethereum mainnet
          "include": "percent_change",  // Include percentage change in price
          "exchange": "uniswapv3",  // Use Uniswap for exchange rates
          "address": "0x6b175474e89094c44da98b954eedeac495271d0f",  // DAI contract address
        });

        // Set the fetched DAI price in state
        setDAI(resp.raw.usdPrice);
      } catch (e) {
        console.error(e);  // Log any error
      }
    };
    init1();  // Initialize the effect
  }, []);  // Empty dependency array means this runs once when the component mounts

  const paymentHandler = async () => {
    try {
      // Fetch user details based on the wallet address
      axios.post("http://localhost:5550/api/auth/fetchdetail", {
        'waddr': address,  // Send wallet address in request
      })
        .then(async (res) => {
          if (res.data === 'no') {
            alert('Your wallet address is not linked!');  // Alert if address is not linked
          } else {
            // Fetch details using a sample email (replace this with actual email logic)
            const res = await axios.post(
              `http://localhost:5550/api/auth/fetchdetail`,
              { email: "example@gmail.com" }
            );
            const details = await res.data.user;
            setMetamaskId(details.metamaskId);  // Set metamask ID from response

            if (address === metamaskID) {  // Ensure the wallet address is linked with the Metamask ID
              if (!amount || !upi) {
                return alert("Missing fields!");  // Ensure both amount and UPI are provided
              }

              // Fetch receiver details based on UPI ID
              const res = await axios.post(
                `http://localhost:5550/api/auth/fetchdetail`,
                { upi: upi }
              );
              const receiver = res.data.metamaskId;  // Get receiver's metamask ID

              // Convert amount to DAI
              const val = ((amount / 83) * Number(DAI).toFixed(2)).toFixed(2);
              const mtm = 0.2 * val;  // Calculate MTM (transaction fee)
              alert("Pay: " + val + '\n' + 'MTM Fee: ' + Number(mtm).toFixed(2) + '\n' + 'Total: ' + (Number(val) + mtm).toFixed(2));

              // Perform the token transfer using thirdweb's transfer function
              await transferDAI({
                to: receiver,  // Transfer to the receiver's wallet
                amount: Number(val) + Number(mtm),  // Total amount including MTM fee
              });

              // Write payment details to backend database
              const date = new Date().toLocaleDateString();  // Get the current date
              axios.post("http://localhost:5550/pay/paymentWrite", {
                date: date,  // Send payment date
                to: upi,  // Send UPI ID
                amt: amount,  // Send the original amount
                sender: walletAddress,  // Send sender's wallet address
                keyword: keyword,  // Send keyword (optional)
                coin: "DAI",  // Coin type (DAI in this case)
              })
                .then((res) => {
                  console.log(res.data);  // Log successful payment details
                })
                .catch((err) => {
                  console.log(err);  // Log any error during backend request
                });
            } else {
              alert('Wallet address not linked with your UPI, Check your wallet address');  // Alert if wallet address doesn't match
            }
          }
        })
        .catch((err) => {
          console.log(err);  // Log any error during the request
        });
    } catch (error) {
      console.log(error);  // Log any unexpected errors
    }
  };

  const requestHandler = () => {
    try {
      // Handle money request by sending UPI and amount to the backend
      (async () => {
        const res = await api.post('/money-transfer/money-requested', { receiver: upi, amount: amount });
        console.log(res.data);  // Log response from the backend
      })();
    } catch (error) {
      console.log(error);  // Log any error during the request
    }
  };

  return (
    <div className="bg-boxbg flex flex-col justify-between w-1/4 h-3/5 rounded-lg p-5 mt-20 border">
      {/* Input section for UPI and Amount */}
      <div className="flex flex-col gap-2">
        <input
          type="text"
          placeholder="UPI Id"
          onChange={(e) => setUpi(e.target.value)}  // Update UPI state on input change
          className="p-4 bg-neutral-700 outline-none rounded-md"
        />
        <input
          type="number"
          placeholder="Amount"
          onChange={(e) => setAmount(e.target.value)}  // Update Amount state on input change
          className="p-4 bg-neutral-700 outline-none rounded-md"
        />
      </div>
      {/* Button section to trigger payment and request */}
      <div className="flex flex-col items-center">
        <div className="flex w-full gap-2">
          <button
            onClick={requestHandler}  // Trigger money request on button click
            className="rounded-full w-full p-3 bg-blue-800"
          >
            Request
          </button>
          <button
            onClick={paymentHandler}  // Trigger payment on button click
            className="rounded-full w-full p-3 bg-fadeBlue"
          >
            Pay
          </button>
        </div>
        <p className="text-sm mt-3 font-thin"> powered by Us</p>  {/* Footer text */}
      </div>
    </div>
  );
};

export default UPI;  // Export UPI component for use in other parts of the app
